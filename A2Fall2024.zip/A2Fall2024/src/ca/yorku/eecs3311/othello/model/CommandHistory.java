/////////////////////

//I ADDED THIS FILE AND THIS CODE

///////////////////////
package ca.yorku.eecs3311.othello.model;

import java.util.Stack;

public class CommandHistory {

	private Stack<Othello> undoStack = new Stack<>();
	private Stack<Othello> redoStack = new Stack<>();

	public void saveState(Othello game) {
		undoStack.push(game.copy());
		redoStack.clear();
	}

	public Othello undo(Othello currentGame) {
		if (undoStack.isEmpty())
			return currentGame;
		redoStack.push(currentGame.copy());
		return undoStack.pop();
	}

	public Othello redo(Othello currentGame) {
		if (redoStack.isEmpty())
			return currentGame;
		undoStack.push(currentGame.copy());
		return redoStack.pop();
	}

	public void clear() {
		undoStack.clear();
		redoStack.clear();
	}
}