package ca.yorku.eecs3311.othello.model;

public abstract class OthelloController {

    protected Othello othello;
    Player player1, player2;

    /**
     * Constructs a new OthelloController with a new Othello game.
     */
    public OthelloController() {
        this.othello = new Othello();
    }

    public void play() {
        while (!othello.isGameOver()) {

            this.report();
            autoPlayIfNeeded();   // <-- I added this 

            char whosTurn = othello.getWhosTurn();
            Move move = null;

            // HUMAN chooses manually
            if (isHumanTurn())
            {
                if (whosTurn == OthelloBoard.P1) move = player1.getMove();
                if (whosTurn == OthelloBoard.P2) move = player2.getMove();

                this.reportMove(whosTurn, move);
                othello.move(move.getRow(), move.getCol());
            }

            // I added this Helps determine if random or greedy is playing
            autoPlayIfNeeded();
        }

        this.reportFinal();
    }

    /**
    * I ADDED THIS HElPS DETERMINE IF IS GREADDY OR RANDOM
     */
    private void autoPlayIfNeeded() {
        if (othello.isGameOver())
            return;

        char turn = othello.getWhosTurn();
        Player current = (turn == OthelloBoard.P1) ? player1 : player2;

        // If current player is AI → make an automatic move
        if (current instanceof PlayerRandom || current instanceof PlayerGreedy) {
            Move aiMove = current.getMove();
            this.reportMove(turn, aiMove);
            othello.move(aiMove.getRow(), aiMove.getCol());
        }
    }

    /**
     * I ADDED THIS: HELPS DETERMIN IF ITS HUMAN TURN
     */
    private boolean isHumanTurn() {
        char turn = othello.getWhosTurn();

        if (turn == OthelloBoard.P1 && !(player1 instanceof PlayerRandom) && !(player1 instanceof PlayerGreedy))
            return true;

        if (turn == OthelloBoard.P2 && !(player2 instanceof PlayerRandom) && !(player2 instanceof PlayerGreedy))
            return true;

        return false;
    }

    protected void reportMove(char whosTurn, Move move) { }
    protected void report() { }
    protected void reportFinal() { }
}
