package ca.yorku.eecs3311.othello.viewcontroller;

import java.io.File;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Scanner;

import ca.yorku.eecs3311.othello.model.CommandHistory;
import ca.yorku.eecs3311.othello.model.Move;
import ca.yorku.eecs3311.othello.model.Othello;
import ca.yorku.eecs3311.othello.model.OthelloBoard;
import ca.yorku.eecs3311.othello.model.Player;
import ca.yorku.eecs3311.othello.model.PlayerGreedy;
import ca.yorku.eecs3311.othello.model.PlayerHuman;
import ca.yorku.eecs3311.othello.model.PlayerRandom;
import ca.yorku.eecs3311.util.Observable;
import ca.yorku.eecs3311.util.Observer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class OthelloApplication extends Application implements Observer {
	/*
	 * created Local variables for better implentation had to swicth from using an
	 * Array of othello object to just one for the sake of better implenting
	 * observsble pattern
	 */

	private Label statusLabel;
	private Othello game;
	private Button[][] buttons;

	private Player[] player1 = new Player[1];
	private Player[] player2 = new Player[1];

	@Override
	public void start(Stage stage) throws Exception {

		game = new Othello();
		game.attach(this);

		// UI controls
		ComboBox<String> p1Choice = new ComboBox<>();
		p1Choice.getItems().addAll("Human", "Random", "Greedy");
		p1Choice.setValue("Human"); // default

		ComboBox<String> p2Choice = new ComboBox<>();
		p2Choice.getItems().addAll("Human", "Random", "Greedy");
		p2Choice.setValue("Human"); // default

		Button startBtn = new Button("Start Game");

		GridPane grid = new GridPane();
		grid.setHgap(2);
		grid.setVgap(2);

		buttons = new Button[8][8];
		CommandHistory history = new CommandHistory();

		Button undoBtn = new Button("Undo");
		Button redoBtn = new Button("Redo");
		Button restartBtn = new Button("Restart");
		Button saveBtn = new Button("Save");
		Button loadBtn = new Button("Load");

		statusLabel = new Label("Turn: Black    Black: 2    White: 2");
		statusLabel.setStyle("-fx-font-size: 15px;" + "-fx-font-weight: bold;");

		// Build board buttons
		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				Button b = new Button("");
				b.setPrefSize(70, 70);
				b.setStyle("-fx-background-color: #228B22;" + // green board
						"-fx-border-color: black;" + "-fx-border-width: 1px;" + "-fx-font-size: 32px;");
				final int row = r;
				final int col = c;

				b.setOnAction(e -> {
					// snapshot BEFORE trying the human move
					Othello beforeMove = game.copy();

					// try human move
					boolean moved = game.move(row, col);

					if (moved) {
						// only save state when a real change happened
						history.saveState(beforeMove.copy());

						// update UI (observers will also be notified by model, but update here too)
						updateBoard(game, buttons);

						// autoplay random and greedy as needed; save snapshots for each AI move too
						while (true) {
							if (game.isGameOver())
								break;

							char turn2 = game.getWhosTurn();

							// P1 is AI?
							if (turn2 == OthelloBoard.P1 && player1[0] != null
									&& !(player1[0] instanceof PlayerHuman)) {
								Othello beforeAI = game.copy();
								Move m = player1[0].getMove();
								boolean aiMoved = game.move(m.getRow(), m.getCol());
								if (aiMoved) {
									history.saveState(beforeAI.copy());
									updateBoard(game, buttons);
									continue;
								} else {
									break;
								}
							}

							// P2 is AI?
							if (turn2 == OthelloBoard.P2 && player2[0] != null
									&& !(player2[0] instanceof PlayerHuman)) {
								Othello beforeAI = game.copy();
								Move m = player2[0].getMove();
								boolean aiMoved = game.move(m.getRow(), m.getCol());
								if (aiMoved) {
									history.saveState(beforeAI.copy());
									updateBoard(game, buttons);
									continue;
								} else {
									break;
								}
							}

							break; // stop when it's a human's turn
						} // end autoplay loop
					} // end if moved
				});

				buttons[r][c] = b;
				grid.add(b, c, r);
			}
		}

		// initial draw
		updateBoard(game, buttons);

		// UNDO
		undoBtn.setOnAction(e -> {
			Othello newGame = history.undo(game);
			if (newGame != null) {
				game = newGame;
				rebindPlayersToGame(game);
				// re-register observer (in case newGame lost observers)
				safeRegisterObserver(game);
				updateBoard(game, buttons);
			}
		});

		// REDO
		redoBtn.setOnAction(e -> {
			Othello newGame = history.redo(game);
			if (newGame != null) {
				game = newGame;
				rebindPlayersToGame(game);
				safeRegisterObserver(game);
				updateBoard(game, buttons);
			}
		});

		// RESTART
		restartBtn.setOnAction(e -> {
			game = new Othello();
			history.clear();
			rebindPlayersToGame(game);
			safeRegisterObserver(game);
			updateBoard(game, buttons);
		});

		// SAVE
		saveBtn.setOnAction(e -> {
			saveGame(game);
		});

		// LOAD
		loadBtn.setOnAction(e -> {
			// Use the robust loader below which will replace `game`
			loadGame(buttons, history);
		});

		HBox controls = new HBox(10, undoBtn, redoBtn, restartBtn, saveBtn, loadBtn);
		HBox playerSelect = new HBox(10, new Label("P1:"), p1Choice, new Label("P2:"), p2Choice, startBtn);

		// START button behavior: reset game and create chosen players
		startBtn.setOnAction(e -> {
			game = new Othello();
			history.clear();
			rebindPlayersToGame(game); // if players were already set, rebind them
			safeRegisterObserver(game);

			// Create player1
			String p1 = p1Choice.getValue();
			if (p1.equals("Human"))
				player1[0] = new PlayerHuman(game, OthelloBoard.P1);
			else if (p1.equals("Random"))
				player1[0] = new PlayerRandom(game, OthelloBoard.P1);
			else // Greedy
				player1[0] = new PlayerGreedy(game, OthelloBoard.P1);

			// Create player2
			String p2 = p2Choice.getValue();
			if (p2.equals("Human"))
				player2[0] = new PlayerHuman(game, OthelloBoard.P2);
			else if (p2.equals("Random"))
				player2[0] = new PlayerRandom(game, OthelloBoard.P2);
			else // Greedy
				player2[0] = new PlayerGreedy(game, OthelloBoard.P2);

			updateBoard(game, buttons);

			// Autoplay AI until human's turn
			while (true) {
				if (game.isGameOver())
					break;
				char turn = game.getWhosTurn();

				if (turn == OthelloBoard.P1 && !(player1[0] instanceof PlayerHuman)) {
					Move m = player1[0].getMove();
					game.move(m.getRow(), m.getCol());
					updateBoard(game, buttons);
					continue;
				}

				if (turn == OthelloBoard.P2 && !(player2[0] instanceof PlayerHuman)) {
					Move m = player2[0].getMove();
					game.move(m.getRow(), m.getCol());
					updateBoard(game, buttons);
					continue;
				}
				break;
			}
		});

		ScrollPane scroll = new ScrollPane(grid);
		scroll.setFitToWidth(true);
		scroll.setFitToHeight(true);
		scroll.setPannable(true);
		scroll.setStyle("-fx-background: #228B22;");

		VBox layout = new VBox(12, statusLabel, playerSelect, scroll, controls);

		Scene scene = new Scene(layout);

		stage.setTitle("Othello");
		stage.setScene(scene);

		stage.setWidth(595);
		stage.setHeight(700);

		stage.show();
	}

	// ------------------------
	// updateBoard + UI helpers
	// ------------------------
	private void updateBoard(Othello game, Button[][] buttons) {
		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				char t = game.getToken(r, c);
				buttons[r][c].setText(tokenToSymbol(t));

				if (t == OthelloBoard.P1) {
					buttons[r][c].setStyle("-fx-font-size: 32px;" + "-fx-text-fill: black;"
							+ "-fx-background-color: #228B22;" + "-fx-border-color: black;" + "-fx-border-width: 1px;");
				} else if (t == OthelloBoard.P2) {
					buttons[r][c].setStyle("-fx-font-size: 32px;" + "-fx-text-fill: white;"
							+ "-fx-background-color: #228B22;" + "-fx-border-color: black;" + "-fx-border-width: 1px;");
				} else {
					buttons[r][c].setStyle(
							"-fx-background-color: #228B22;" + "-fx-border-color: black;" + "-fx-border-width: 1px;");
				}
			}
		}
		updateStatus(game);
	}

	private void updateStatus(Othello game) {
		char turn = game.getWhosTurn();
		int countX = 0;
		int countO = 0;
		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				char t = game.getToken(r, c);
				if (t == OthelloBoard.P1)
					countX++;
				if (t == OthelloBoard.P2)
					countO++;
			}
		}
		String turnName = (turn == OthelloBoard.P1 ? "Black" : "White");
		statusLabel.setText("Turn: " + turnName + "    Black: " + countX + "    White: " + countO);
	}

	private String tokenToSymbol(char t) {
		if (t == OthelloBoard.P1)
			return "●";
		if (t == OthelloBoard.P2)
			return "●";
		return "";
	}

	// ------------------------
	// Save / Load
	// ------------------------
	private void saveGame(Othello game) {
		try {
			File file = new File("savegame.txt");
			PrintWriter out = new PrintWriter(file);

			// Save whose turn
			out.println(game.getWhosTurn());

			// Save board
			for (int r = 0; r < 8; r++) {
				StringBuilder sb = new StringBuilder();
				for (int c = 0; c < 8; c++) {
					sb.append(game.getToken(r, c));
				}
				out.println(sb.toString());
			}
			out.close();

			System.out.println("Game saved to: " + file.getAbsolutePath());

		} catch (Exception e) {
			System.out.println("Error saving game: " + e.getMessage());
		}
	}

	private void loadGame(Button[][] buttons, CommandHistory history) {
		try {
			File file = new File("savegame.txt");
			if (!file.exists()) {
				System.out.println("Save file not found: " + file.getAbsolutePath());
				return;
			}

			Scanner sc = new Scanner(file);

			// Read turn
			char turn = sc.nextLine().charAt(0);

			// Read board
			char[][] board = new char[8][8];
			for (int r = 0; r < 8; r++) {
				String line = sc.nextLine();
				for (int c = 0; c < 8; c++) {
					board[r][c] = line.charAt(c);
				}
			}
			sc.close();

			// Create fresh game and restore board directly
			Othello newGame = new Othello();
			OthelloBoard b = newGame.getBoard();
			for (int r = 0; r < 8; r++)
				for (int c = 0; c < 8; c++)
					b.setToken(r, c, board[r][c]);

			// restore turn
			newGame.setWhosTurn(turn);

			// replace active game
			game = newGame;
			history.clear();

			// rebind players to the new game and re-register view as observer
			rebindPlayersToGame(game);
			safeRegisterObserver(game);

			updateBoard(game, buttons);
			System.out.println("Game loaded successfully!");

		} catch (Exception e) {
			System.out.println("Error loading game: " + e.getMessage());
			e.printStackTrace();
		}
	}

	// ------------------------
	// Helper: rebind players to a new game instance (uses reflection)
	// ------------------------
	private void rebindPlayersToGame(Othello newGame) {
		try {
			if (player1[0] != null) {
				boolean rebound = trySetOthelloViaMethod(player1[0], newGame);
				if (!rebound)
					trySetOthelloViaField(player1[0], newGame);
			}
			if (player2[0] != null) {
				boolean rebound = trySetOthelloViaMethod(player2[0], newGame);
				if (!rebound)
					trySetOthelloViaField(player2[0], newGame);
			}
		} catch (Exception e) {
			// if reflection rebinding fails quietly continue (players may be recreated
			// later)
			System.out.println("Warning: failed to rebind players to new game: " + e.getMessage());
		}
	}

	private boolean trySetOthelloViaMethod(Player p, Othello newGame) {
		try {
			Method m = p.getClass().getMethod("setOthello", Othello.class);
			m.invoke(p, newGame);
			return true;
		} catch (NoSuchMethodException nsme) {
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	private boolean trySetOthelloViaField(Player p, Othello newGame) {
		try {
			Class<?> cls = p.getClass();
			while (cls != null) {
				for (Field f : cls.getDeclaredFields()) {
					if (f.getType().equals(Othello.class)) {
						f.setAccessible(true);
						f.set(p, newGame);
						return true;
					}
				}
				cls = cls.getSuperclass();
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	private void safeRegisterObserver(Othello game) {
		try {
			game.attach(this);
		} catch (Exception e) {
			try {

				Method m = game.getClass().getMethod("attach", Observer.class);
				m.invoke(game, this);
			} catch (Exception ex) {
				// ignore
			}
		}
	}

	// ------------------------
	// Observer callback
	// ------------------------
	@Override
	public void update(Observable o) {
		// model changed -> refresh UI
		updateBoard(game, buttons);
	}

	// ------------------------
	// main
	// ------------------------
	public static void main(String[] args) {
		OthelloApplication view = new OthelloApplication();
		launch(args);
	}
}
