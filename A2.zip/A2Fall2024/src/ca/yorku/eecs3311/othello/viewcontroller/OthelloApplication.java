package ca.yorku.eecs3311.othello.viewcontroller;

//////added this
import ca.yorku.eecs3311.othello.model.CommandHistory;
import ca.yorku.eecs3311.othello.model.Move;
import ca.yorku.eecs3311.othello.model.Othello;
import ca.yorku.eecs3311.othello.model.OthelloBoard;
import ca.yorku.eecs3311.othello.model.Player;
import ca.yorku.eecs3311.othello.model.PlayerGreedy;
import ca.yorku.eecs3311.othello.model.PlayerHuman;
import ca.yorku.eecs3311.othello.model.PlayerRandom;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
//////

public class OthelloApplication extends Application {
	// REMEMBER: To run this in the lab put
	// --module-path "/usr/share/openjfx/lib" --add-modules
	// javafx.controls,javafx.fxml
	// in the run configuration under VM arguments.
	// You can import the JavaFX.prototype launch configuration and use it as well.

	@Override
	public void start(Stage stage) throws Exception {
		// Create and hook up the Model, View and the controller

		// MODEL
		final Othello[] othello = { new Othello() };

		final Player[] player1 = { null };
		final Player[] player2 = { null };

		// CONTROLLER
		// CONTROLLER->MODEL hookup

		// VIEW
		// VIEW->CONTROLLER hookup
		// MODEL->VIEW hookup

		////////////////////////// DOwn
		// Player selection controls
		ComboBox<String> p1Choice = new ComboBox<>();
		p1Choice.getItems().addAll("Human", "Random", "Greedy");
		p1Choice.setValue("Human"); // default

		ComboBox<String> p2Choice = new ComboBox<>();
		p2Choice.getItems().addAll("Human", "Random", "Greedy");
		p2Choice.setValue("Human"); // default

		Button startBtn = new Button("Start Game");

		////////////////////////// up

		GridPane grid = new GridPane();

		////////// i added this
		grid.setHgap(2);
		grid.setVgap(2);

		Button[][] buttons = new Button[8][8];
		///////////
		CommandHistory history = new CommandHistory();

		Button undoBtn = new Button("Undo");
		Button redoBtn = new Button("Redo");
		Button restartBtn = new Button("Restart");
		Button saveBtn = new Button("Save");
		Button loadBtn = new Button("Load");
		//////////

		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				Button b = new Button("");
				b.setPrefSize(50, 50);

				// Green background + border
				b.setStyle("-fx-background-color: #228B22;" + // green board
						"-fx-border-color: black;" + "-fx-border-width: 1px;");

				int row = r;
				int col = c;

				b.setOnAction(e -> {
					history.saveState(othello[0]);

					// Human move
					if (othello[0].move(row, col)) {
						updateBoard(othello[0], buttons);

						// If next player is AI → let it move automatically
						// Automatically let AI continue playing
						while (true) {
							char turn2 = othello[0].getWhosTurn();

							if (turn2 == OthelloBoard.P1 && !(player1[0] instanceof PlayerHuman)) {
								Move m = player1[0].getMove();
								othello[0].move(m.getRow(), m.getCol());
								updateBoard(othello[0], buttons);
								continue;
							}

							if (turn2 == OthelloBoard.P2 && !(player2[0] instanceof PlayerHuman)) {
								Move m = player2[0].getMove();
								othello[0].move(m.getRow(), m.getCol());
								updateBoard(othello[0], buttons);
								continue;
							}

							break; // stop when it's a human's turn
						}

					}
				});

				buttons[r][c] = b;
				grid.add(b, c, r);
			}
		}

		updateBoard(othello[0], buttons);

		/////////

		// SCENE

		//////////// i added this
		// UNDO button behavior
		undoBtn.setOnAction(e -> {
			othello[0] = history.undo(othello[0]);
			updateBoard(othello[0], buttons);
		});

		// REDO button behavior
		redoBtn.setOnAction(e -> {
			othello[0] = history.redo(othello[0]);
			updateBoard(othello[0], buttons);
		});

		// RESTART button behavior
		restartBtn.setOnAction(e -> {
			othello[0] = new Othello();
			history.clear();
			updateBoard(othello[0], buttons);
		});

		// SAVE button behavior
		saveBtn.setOnAction(e -> {
			saveGame(othello[0]);
		});

		// LOAD button behavior
		loadBtn.setOnAction(e -> {
			loadGame(othello[0], buttons);
		});

		////////////

		/////// replacing this with below..........Scene scene = new Scene(grid);

		HBox controls = new HBox(10, undoBtn, redoBtn, restartBtn, saveBtn, loadBtn);

		HBox playerSelect = new HBox(10, new Label("P1:"), p1Choice, new Label("P2:"), p2Choice, startBtn);
		//////// down
		// START BUTTON BEHAVIOR
		startBtn.setOnAction(e -> {
			// Reset game
			othello[0] = new Othello();
			history.clear();
			updateBoard(othello[0], buttons);

			// Choose players
			String p1 = p1Choice.getValue();
			String p2 = p2Choice.getValue();

			// Create player1
			if (p1.equals("Human"))
				player1[0] = new PlayerHuman(othello[0], OthelloBoard.P1);
			if (p1.equals("Random"))
				player1[0] = new PlayerRandom(othello[0], OthelloBoard.P1);
			if (p1.equals("Greedy"))
				player1[0] = new PlayerGreedy(othello[0], OthelloBoard.P1);

			// Create player2
			if (p2.equals("Human"))
				player2[0] = new PlayerHuman(othello[0], OthelloBoard.P2);
			if (p2.equals("Random"))
				player2[0] = new PlayerRandom(othello[0], OthelloBoard.P2);
			if (p2.equals("Greedy"))
				player2[0] = new PlayerGreedy(othello[0], OthelloBoard.P2);

			// After starting, if P1 is AI → let it move immediately
			// After starting, let AI auto-play until it's a human's turn
			while (true) {
				char turn = othello[0].getWhosTurn();

				if (turn == OthelloBoard.P1 && !(player1[0] instanceof PlayerHuman)) {
					Move m = player1[0].getMove();
					othello[0].move(m.getRow(), m.getCol());
					updateBoard(othello[0], buttons);
					continue;
				}

				if (turn == OthelloBoard.P2 && !(player2[0] instanceof PlayerHuman)) {
					Move m = player2[0].getMove();
					othello[0].move(m.getRow(), m.getCol());
					updateBoard(othello[0], buttons);
					continue;
				}

				break; // stop when it's a human's turn
			}

		});

		//////// up
		VBox layout = new VBox(20, playerSelect, grid, controls);

		Scene scene = new Scene(layout);

		/////////
		stage.setTitle("Othello");
		stage.setScene(scene);

		// LAUNCH THE GUI
		stage.show();
	}

	/////// i added this
	private void updateBoard(Othello game, Button[][] buttons) {
		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				char t = game.getToken(r, c);
				buttons[r][c].setText(tokenToSymbol(t));

			}
		}
	}

	//////////
	///
	///
	///
	private String tokenToSymbol(char t) {
		if (t == 'X')
			return "⬤"; // solid black circle
		if (t == 'O')
			return "⚪"; // solid white filled circle
		return "";
	}

////
	// ============================
	// PUT SAVE/LOAD METHODS HERE
	// ============================

	// ===== SAVE GAME TO TEXT FILE =====
	private void saveGame(Othello game) {
		try {
			java.io.PrintWriter out = new java.io.PrintWriter("savegame.txt");

			// Save whose turn
			out.println(game.getWhosTurn());

			// Save board
			for (int r = 0; r < 8; r++) {
				for (int c = 0; c < 8; c++) {
					out.print(game.getToken(r, c));
				}
				out.println();
			}

			out.close();
			System.out.println("Game saved to savegame.txt");
		} catch (Exception e) {
			System.out.println("Error saving game: " + e.getMessage());
		}
	}

	// ===== LOAD GAME FROM TEXT FILE =====
	private void loadGame(Othello game, Button[][] buttons) {
		try {
			java.io.File file = new java.io.File("savegame.txt");
			java.util.Scanner sc = new java.util.Scanner(file);

			char turn = sc.nextLine().charAt(0);

			char[][] board = new char[8][8];
			for (int r = 0; r < 8; r++) {
				String line = sc.nextLine();
				for (int c = 0; c < 8; c++) {
					board[r][c] = line.charAt(c);
				}
			}
			sc.close();

			// Reset game
			game = new Othello();

			// Rebuild board by performing valid moves
			for (int r = 0; r < 8; r++) {
				for (int c = 0; c < 8; c++) {
					char expected = board[r][c];
					char actual = game.getToken(r, c);

					if (expected != OthelloBoard.EMPTY && expected != actual) {
						game.move(r, c);
					}
				}
			}

			// Adjust turn
			while (game.getWhosTurn() != turn) {
				game.move(-1, -1); // skip move
			}

			updateBoard(game, buttons);
			System.out.println("Game loaded!");

		} catch (Exception e) {
			System.out.println("Error loading game: " + e.getMessage());
		}
	}

////	
	//////////////

	public static void main(String[] args) {
		OthelloApplication view = new OthelloApplication();
		launch(args);
	}
}
